Uninstall Tool 3.7.3 Build 5719 (Repack by Dodakaedr)

This version comes pre-activated. The installer looks kind of flimsy, but it gets the job done
and supports automation by means of command line switches!

Command line switches:
• Silent installation: /V
• Silent unpack: /V /P
• No Desktop link: /ND
• No Start Menu link: /NS
• Enable software autoupdate: /NU
• Pin to Taskbar: /T
• Pin to Start Menu: /S
• Russian interface: default (no switch)
• English interface: /E
• Ukrainian interface: /U
• Belarusian interface: /B
• Path selector: /D=directory

The /D switch must come last.
Example: setup.exe /V /E /P /D="D:\Uninstall Tool Portable"

Thank you for downloading from Enderman!
https://enderman.ch